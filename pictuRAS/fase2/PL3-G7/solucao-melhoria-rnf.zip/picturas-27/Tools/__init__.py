class BaseTool:
    pass